﻿
#include <iostream>
#include <list>
#include <string>
using namespace std;

int main()
{
    setlocale(0, "rus");
    int DEliteli[101];
   /*int Summ[101];*/
    int n;
    cout << "Введите n\t\n";
    cin >> n;
    if (n < 1)
    {
        cout << "тут нет делителей";
    }
    else
    {


        /*if (n > 100) {
            cout << "Напишите число меньше 100 и больше 0";
        }
          else
        {*/
            int delit = 9999;
            int perenenn = 0;
                for (int i = 1;i <= n;i++)
                {
                  if (n % i == 0)
                     {
                 DEliteli[perenenn]=i;
                 perenenn++;
                 cout << i<<"\t\n";
                      }
                }
                
               
                int prosh=DEliteli[0];
                int poziqia = 0;
                    for (int i = 0;i < perenenn;i++)
                    {
                      int summ =0;

                 /* if (DEliteli[i] >9 && DEliteli[i] <100)
                 {
                     int per = DEliteli[i];  
                     int koneq = per % 10;
                     int perv = per / 10;
                    
                      summ = perv + koneq;
                 
                 }*/
                      if (DEliteli[i] > 9)
                      {
                          
                          string po_qifram = to_string(DEliteli[i]);
                          for (int j = 0;j < po_qifram.length();j++)
                          {
                              int lol=po_qifram[j] - '0';
                              summ += lol;
                          }
                      }
                      else
                      {
                          summ = i;
                      }


                 if (prosh < summ)
                     {
                     
                         prosh = summ;                         
                    delit=DEliteli[i];
                       
                      

                     }
                
                    } 
                    



                    cout << "САмая большая сумма делителя у числа  "<<n<<"  это  " << prosh <<" сам делитель "<< delit;

                    

         // }
        
       



    }
}
